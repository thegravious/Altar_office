import React from "react";
import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "./firebase";
// import  googleLogo  from "../../img/googlelogo.png";

const Login = () => {
  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user; // Get user info
      console.log("User Info:", user);
      alert(`Welcome ${user.displayName || "User"}!`);
      if(user){
        window.location.href="/home"
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert("Failed to log in. Please try again.");
    }
  };

    return (
        <div>
            <div className='min-h-screen flex items-center bg-[#FFF9F9]'>
                <div className='h-52 flex flex-col items-start justify-between w-[50vw] ml-40'>
                    <div className='flex justify-center items-center'>
                        {/* <LuClipboardList className='text-4xl text-[#7B1984] mr-2' /> */}
                        <span className='text-4xl text-[#7B1984] font-semibold'>TaskBuddy</span>
                    </div>
                    <div>
                        <p className='text-xl'>
                            Streamline your workflow and track progress effortlessly <br /> with our all-in-one task management app.
                        </p>
                    </div>
                    <button
                        className='bg-[#292929] p-5 rounded-3xl flex justify-between items-center'  onClick={handleGoogleLogin}>
                        <img src={"/googlelogo.png"} className='w-10' alt="" />
                        <p className='text-2xl text-white mx-10'>Continue With Google</p>
                    </button>
                </div>
                <div>
                    <img
                        className='w-[60vw] rounded-2xl shadow-xl h-auto relative right-0 lg:right-[-300px]'
                        src={"altarloginphoto.png"}
                        alt="Altar Login Illustration"
                    />
                </div>
            </div>
        </div>
    );
};

export default Login;
