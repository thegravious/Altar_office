import React from 'react';
import Addmini from "../addtaskmini/AddtaskMini"
import { FaChevronUp, FaChevronDown } from "react-icons/fa";
import { FaPlus } from "react-icons/fa6";
import DisplayTask from "../displayTask/DisplayTask"

const Todo = ({setTasks, updatedTasks, result }) => {
    const [addtask, setaddTask] = React.useState(false)
    const [isopen, setIsOpen] = React.useState(true);
    // category value -> work, persional, defafult
    // console.log(tosearch)

    const existingTasks = JSON.parse(localStorage.getItem("TaskDetails")) || [];
    const inProcessTasks = existingTasks.filter(task => task.TaskStatus === "To Do")
    console.log(updatedTasks)
    return (
        <div className=" border divide-y rounded-lg overflow-hidden max-w-6xl mt-4 mb-10 mx-auto">
            <div>
                <div
                    className={`justify-between w-full text-base text-left py-4 px-6 text-black bg-[#FAC3FF] flex transition-all items-center`}
                >
                    <span className="mr-4">
                        {`ToDo (${inProcessTasks.length})`}
                    </span>
                    <button
                        type="button"
                        aria-expanded={isopen}
                        aria-label={isopen ? "Collapse section" : "Expand section"}
                        onClick={() => setIsOpen(!isopen)}
                        className="flex items-center"
                    >
                        {isopen ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                </div>
                <div className={`${isopen ? "block" : "hidden"} py-4 px-6 min-h-[30vh] bg-gray-50`}>
                    <button onClick={() => {
                        setaddTask(!addtask)
                    }}><div className='flex justify-center items-center uppercase'> <FaPlus className='text-[#7b1984]' /> Add Task</div></button>
                    <hr className="h-px my-1 w-full bg-gray-900 border-0 dark:bg-gray-300"></hr>
                    <div className={`${addtask ? "block" : "hidden"}`}>
                        <Addmini setTasks={setTasks} />
                    </div>
                    {
                        result && result.length > 0 ? (
                            result.filter(data => data.TaskStatus === "To Do").map((task) => (
                                <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                            ))
                        ) : (
                            updatedTasks && updatedTasks.length > 0 ? (
                                updatedTasks.filter(task => task.TaskStatus === "To Do").map((task) => (
                                    <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                ))
                            ) : 
                            (
                                inProcessTasks.filter(task => task.TaskStatus === "To Do").map((task)=>(
                                    <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                ))
                            )
                        )
                    }
                </div>
            </div>
        </div>
    );
}

export default Todo;

