import React from 'react';
import { MdDragIndicator } from "react-icons/md";
import { FaChevronUp, FaChevronDown } from "react-icons/fa";
import DisplayTask from '../displayTask/DisplayTask';


const CompletedCard = ({ tasks, setTasks, updatedTasks, result }) => {
    const [isopen, setIsOpen] = React.useState(true);
    const existingTasks = JSON.parse(localStorage.getItem("TaskDetails")) || [];
    const inProcessTasks = existingTasks.filter(task => task.TaskStatus === "Completed")

    return (
        <div className="border divide-y rounded-lg overflow-hidden max-w-6xl mt-4 mb-10 mx-auto">
            <div>
                <div
                    className={`justify-between w-full text-base text-left py-4 px-6 text-black bg-[#CEFFCC] flex transition-all items-center`}
                >
                    <span className="mr-4">
                        {`Completed (${inProcessTasks.length})`}
                    </span>
                    <button
                        type="button"
                        aria-expanded={isopen}
                        aria-label={isopen ? "Collapse section" : "Expand section"}
                        onClick={() => setIsOpen(!isopen)}
                        className="flex items-center"
                    >
                        {isopen ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                </div>
                <div className={`${isopen ? "block" : "hidden"} py-4 px-6 min-h-[30vh] flex flex-col bg-gray-50`}>
                {
                        result && result.length > 0 ? (
                            result.filter(data => data.TaskStatus === "Completed").map((task) => (
                                <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                            ))
                        ) : (
                            updatedTasks && updatedTasks.length > 0 ? (
                                updatedTasks.filter(task => task.TaskStatus === "Completed").map((task) => (
                                    <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                ))
                            ) : 
                            (
                                inProcessTasks.filter(task => task.TaskStatus === "Completed").map((task)=>(
                                    <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                ))
                            )
                        )
                    }
                </div>
            </div>
        </div>
    );
}

export default CompletedCard;
