import React from 'react';
import { FaChevronUp, FaChevronDown } from "react-icons/fa";
import DisplayTask from '../displayTask/DisplayTask';

const InprocessCard = ({ tasks, setTasks, updatedTasks, result }) => {
    const [bulkDelete, setBulkDelete] = React.useState([])
    // console.log(bulkDelete)
    const [isChecked, setIsChecked] = React.useState(false)
    const [isCheckBoxOpen, setIscCheckBoxOpen] = React.useState(false)
    const [isopen, setIsOpen] = React.useState(true);
    const existingTasks = JSON.parse(localStorage.getItem("TaskDetails")) || [];
    const inProcessTasks = existingTasks.filter(task => task.TaskStatus === "In Progress")


    return (
        <div className="border divide-y rounded-lg overflow-hidden max-w-6xl mt-4 mb-10 mx-auto">
            <div>
                <div
                    className={`justify-between w-full text-base text-left py-4 px-6 text-black bg-[#85D9F1] flex transition-all items-center`}
                >
                    <span className="mr-4">
                        {`In Process (${inProcessTasks.length})`}
                    </span>
                    <button
                        type="button"
                        aria-expanded={isopen}
                        aria-label={isopen ? "Collapse section" : "Expand section"}
                        onClick={() => setIsOpen(!isopen)}
                        className="flex items-center"
                    >
                        {isopen ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                </div>
                <div className={`${isopen ? "block" : "hidden"} py-4 px-6 min-h-[30vh] flex flex-col bg-gray-50`}>
                    {
                        result && result.length > 0 ? (
                            result.filter(data => data.TaskStatus === "In Progress").map((task) => (
                                <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                            ))
                        ) : (
                            updatedTasks && updatedTasks.length > 0 ? (
                                updatedTasks.filter(task => task.TaskStatus === "In Progress").map((task) => (
                                    <DisplayTask updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                ))
                            ) :
                                (
                                    inProcessTasks.filter(task => task.TaskStatus === "In Progress").map((task) => (
                                        <DisplayTask bulkDelete={bulkDelete} setBulkDelete={setBulkDelete} isChecked={isChecked} setIsChecked={setIsChecked} updatedTasks={updatedTasks} key={task.Id} task={task} setTasks={setTasks} />
                                    ))
                                )
                        )
                    }
                </div>
            </div>

            {/* this is the bulk delete section */}

            {
                bulkDelete && bulkDelete.length>0? (
                    <>
                    <div className={`fixed flex items-center justify-between p-10 h-14 rounded-xl bottom-10 left-1/2 transform -translate-x-1/2 bg-black w-[40vw] text-center py-2`}>
                <div className='border border-gray-500 w-full p-1 rounded-full mr-3'>
                    <p className='text-white'>
                        {/* {selectedTasks.length} Tasks Seleted */}
                    </p>
                </div>
                <div className='flex justify-between'>
                    <div>
                        <button
                            // onClick={handleDelete}
                            className="border flex justify-center items-center border-red-800 bg-[#FF353524] text-red-500 text-sm px-3 py-2 rounded-xl w-32 h-[40px] mr-3">delete</button>
                    </div>
                    <div>
                        <button
                            type="button"
                            onClick={() => setIscCheckBoxOpen(!isCheckBoxOpen)}
                            className="border flex justify-center items-center border-gray-300 bg-[#8d8a8a39] text-white text-sm px-3 py-2 rounded-full w-32 h-[40px]"
                        >
                            Category
                        </button>
                        <div className={`${isCheckBoxOpen ? "block" : "hidden"} absolute bg-black border p-3 bottom-16 right-6 text-white rounded-lg w-40 mt-2`}>
                            <button
                                type="button"
                                className="block w-full text-left px-3 py-1"
                                // onClick={handleChangeStatus}
                                value="To Do"
                            >
                                To Do
                            </button>
                            <button
                                type="button"
                                className="block w-full text-left px-3 py-1"
                                // onClick={handleChangeStatus}
                                value="In Progress"
                            >
                                In Progress
                            </button>
                            <button
                                type="button"
                                className="block w-full text-left px-3 py-1"
                                // onClick={handleChangeStatus}
                                value="Completed"
                            >
                                Completed
                            </button>
                        </div>
                    </div>
                </div>
            </div>
                    </>
                ):
                (
                    ""
                )
            }

        </div>
    );
}

export default InprocessCard;



